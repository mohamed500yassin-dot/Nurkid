import React, { useState, useEffect, useRef } from 'react';
import { 
  BookOpen, 
  Search, 
  ChevronLeft, 
  Home,
  Play, 
  Pause, 
  Sun, 
  Moon,
  Loader2,
  MessageCircle,
  Send,
  Zap,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { motion, AnimatePresence } from "motion/react";

// Initialize Gemini AI
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

interface Surah {
  number: number;
  name: string;
  englishName: string;
  englishNameTranslation: string;
  numberOfAyahs: number;
  revelationType: string;
}

interface Message {
  role: 'user' | 'assistant';
  text: string;
}

export default function App() {
  const [showSplash, setShowSplash] = React.useState(true);
  const [activeTab, setActiveTab] = useState('home');
  const [isDarkMode, setIsDarkMode] = useState(false); // Kids theme is better in light mode by default
  const [selectedSurah, setSelectedSurah] = useState<Surah | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoadingAudio, setIsLoadingAudio] = useState(false);
  const [surahs, setSurahs] = useState<Surah[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [audioUnlocked, setAudioUnlocked] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', text: 'Assalamu Alaikum kleine vriend! Ik ben Nur, jouw vrolijke AI-vriendje. Wil je samen iets leren over de Koran of heb je een leuke vraag? 🌟' }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  const audioRef = useRef<HTMLAudioElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Splash screen timer
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 3500);
    return () => clearTimeout(timer);
  }, []);

  const theme = {
    bg: isDarkMode ? 'bg-[#0F172A]' : 'bg-[#FFFBEB]',
    text: isDarkMode ? 'text-white' : 'text-[#92400E]',
    subText: isDarkMode ? 'text-white/40' : 'text-[#92400E]/60',
    glass: isDarkMode 
      ? 'bg-white/10 border-white/10 backdrop-blur-2xl' 
      : 'bg-white/80 border-orange-200 backdrop-blur-2xl',
    card: isDarkMode 
      ? 'bg-white/5 border-white/10 backdrop-blur-lg' 
      : 'bg-white border-orange-100 shadow-sm',
    input: isDarkMode 
      ? 'bg-white/5 border-white/10 backdrop-blur-md' 
      : 'bg-white border-orange-200 shadow-inner'
  };

  useEffect(() => {
    fetch('https://api.alquran.cloud/v1/surah')
      .then(res => res.json())
      .then(data => setSurahs(data.data))
      .catch(() => setError("Kon de Koran-gegevens niet laden."));
  }, []);

  useEffect(() => {
    if (activeTab === 'chat') {
      const timer = setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [messages, isTyping, activeTab]);

  const unlockAudio = () => {
    if (audioRef.current) {
      audioRef.current.play().catch(() => {});
      audioRef.current.pause();
      setAudioUnlocked(true);
    }
  };

  const playSurah = (s: Surah) => {
    if (!audioUnlocked) unlockAudio();
    setIsLoadingAudio(true);
    setSelectedSurah(s);
    const audioUrl = `https://server8.mp3quran.net/afs/${String(s.number).padStart(3, '0')}.mp3`;
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.src = audioUrl;
      audioRef.current.load();
      audioRef.current.play().then(() => {
        setIsPlaying(true);
        setIsLoadingAudio(false);
      }).catch(() => setIsLoadingAudio(false));
    }
  };

  const getAIResponse = async (prompt: string) => {
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          systemInstruction: "Je bent Nur, een vrolijke, lieve en geduldige Islamitische AI-vriend voor kinderen. Geef korte, eenvoudige en inspirerende antwoorden in het Nederlands. Gebruik veel vrolijke emoji's en leg dingen op een begrijpelijke manier uit voor kinderen. Als er een fout is, zeg dan iets liefs als 'Oepsie, mijn wolkje is even in de war!'"
        }
      });
      
      const text = response.text;
      if (!text) throw new Error("EMPTY_RESPONSE");

      return text;
    } catch (e: any) {
      // Check for common API errors or duplicate issues
      if (e.message?.includes('1062')) {
        return "Het systeem merkte een dubbele aanvraag op. Geen zorgen, ik ben er nog. Wat was je vraag?";
      }
      return "Mijn excuses, er is een kleine technische storing (mogelijk een tijdelijke database-vertraging). Probeer het over een paar seconden nog eens.";
    }
  };

  const handleSendMessage = async () => {
    if (!inputText.trim() || isTyping) return;
    
    setError(null);
    const textToSend = inputText.trim();
    const userMsg: Message = { role: 'user', text: textToSend };
    
    setMessages(prev => [...prev, userMsg]);
    setInputText('');
    setIsTyping(true);

    const aiText = await getAIResponse(textToSend);
    setMessages(prev => [...prev, { role: 'assistant', text: aiText }]);
    setIsTyping(false);
  };

  return (
    <AnimatePresence>
      {showSplash ? (
        <motion.div 
          key="splash"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, scale: 1.1 }}
          transition={{ duration: 0.8, ease: "easeInOut" }}
          className="fixed inset-0 z-[1000] bg-orange-500 flex flex-col items-center justify-center p-10"
        >
          {/* BACKGROUND SPARKLES */}
          <div className="absolute inset-0 overflow-hidden opacity-30">
             {[...Array(20)].map((_, i) => (
                <motion.div
                  key={i}
                  animate={{ 
                    opacity: [0, 1, 0],
                    scale: [0, 1.5, 0],
                    y: [0, -100]
                  }}
                  transition={{ 
                    duration: 2 + Math.random() * 2, 
                    repeat: Infinity,
                    delay: Math.random() * 2
                  }}
                  className="absolute bg-white rounded-full"
                  style={{ 
                    width: Math.random() * 6 + 2 + 'px',
                    height: Math.random() * 6 + 2 + 'px',
                    left: Math.random() * 100 + '%',
                    top: Math.random() * 100 + '%'
                  }}
                />
             ))}
          </div>

          <motion.div
            initial={{ scale: 0, rotate: -20 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ 
              type: "spring",
              stiffness: 260,
              damping: 20,
              delay: 0.2
            }}
            className="relative z-10 w-64 h-64 md:w-80 md:h-80"
          >
            {/* Logo Glow */}
            <motion.div 
              animate={{ scale: [1, 1.2, 1], opacity: [0.5, 0.8, 0.5] }}
              transition={{ duration: 3, repeat: Infinity }}
              className="absolute inset-0 bg-yellow-400 blur-[80px] rounded-full opacity-50"
            />
            
            {/* THE LOGO IMAGE */}
            <motion.div
              animate={{ y: [0, -15, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              className="w-full h-full bg-white rounded-[4rem] border-[12px] border-white/30 shadow-2xl overflow-hidden flex items-center justify-center relative"
            >
               {/* Omdat we het plaatje niet fysiek hebben, gebruiken we een placeholder 
                   met dezelfde stijl (vrolijke lachende jongen met sterren) */}
               <img 
                 src="https://picsum.photos/seed/islamic-boy/800/800" 
                 alt="Nur Kids Logo" 
                 referrerPolicy="no-referrer"
                 className="w-full h-full object-cover"
               />
               <div className="absolute inset-0 bg-gradient-to-t from-orange-500/20 to-transparent"></div>
            </motion.div>
          </motion.div>

          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
            className="mt-12 text-5xl font-black text-white tracking-tight drop-shadow-xl"
          >
            Nur Kids
          </motion.h1>
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: 120 }}
            transition={{ delay: 1, duration: 2 }}
            className="h-2 bg-yellow-400 rounded-full mt-4 shadow-lg shadow-yellow-400/20"
          />
        </motion.div>
      ) : (
        <div key="main-app" className={`fixed inset-0 ${theme.bg} ${theme.text} font-sans transition-colors duration-500 overflow-hidden`}>
          <audio ref={audioRef} onEnded={() => setIsPlaying(false)} />

      {/* BACKGROUND BLOBS FOR GLASS EFFECT */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className={`absolute -top-24 -left-24 w-96 h-96 rounded-full blur-[120px] opacity-30 transition-colors duration-1000 ${isDarkMode ? 'bg-orange-500' : 'bg-yellow-300'}`}></div>
        <div className={`absolute top-1/2 -right-24 w-80 h-80 rounded-full blur-[100px] opacity-20 transition-colors duration-1000 ${isDarkMode ? 'bg-emerald-500' : 'bg-orange-300'}`}></div>
        <div className={`absolute -bottom-24 left-1/4 w-96 h-96 rounded-full blur-[120px] opacity-25 transition-colors duration-1000 ${isDarkMode ? 'bg-blue-500' : 'bg-emerald-200'}`}></div>
      </div>

      {/* HEADER */}
      <div className={`relative z-50 h-20 px-6 flex justify-between items-center border-b ${isDarkMode ? 'border-white/10' : 'border-orange-100'} ${theme.glass}`}>
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-orange-500 rounded-2xl flex items-center justify-center text-white shadow-lg transform -rotate-3">
            <ShieldCheck size={20} />
          </div>
          <h1 className="font-black text-2xl tracking-tight text-orange-500">Nur Kids</h1>
        </div>
        <button onClick={() => setIsDarkMode(!isDarkMode)} className={`w-10 h-10 rounded-xl flex items-center justify-center border ${theme.glass} active:scale-90 transition-transform`}>
          {isDarkMode ? <Sun size={18} className="text-yellow-400" /> : <Moon size={18} className="text-black" />}
        </button>
      </div>

      {/* START OVERLAY */}
      {!audioUnlocked && (
        <div className="absolute inset-0 z-[100] bg-orange-500/95 backdrop-blur-2xl flex items-center justify-center p-10 text-center">
          <div className="space-y-8 max-w-xs">
            <div className="w-24 h-24 bg-white rounded-[2.5rem] mx-auto flex items-center justify-center text-orange-500 shadow-2xl animate-bounce">
                <Zap size={48} fill="currentColor" />
            </div>
            <h2 className="text-white text-4xl font-black tracking-tight">Hallo! 👋</h2>
            <p className="text-white/80 text-lg font-bold">Klaar om samen te spelen en te leren?</p>
            <button onClick={unlockAudio} className="w-full bg-white text-orange-500 py-6 rounded-3xl font-black text-2xl shadow-2xl active:scale-95 transition-all">
              START NUR!
            </button>
          </div>
        </div>
      )}

      {/* CONTENT AREA */}
      <div className="h-[calc(100%-80px)] relative">
        
        {/* HOME TAB */}
        {activeTab === 'home' && (
          <div className="h-full overflow-y-auto px-6 pt-8 space-y-8 no-scrollbar animate-in">
            <div className="bg-orange-400 p-10 rounded-[3rem] text-white shadow-2xl relative overflow-hidden">
               <h2 className="text-4xl font-black tracking-tight leading-tight">Hallo Vriend! ✨</h2>
               <p className="mt-4 text-orange-100 font-bold text-lg">Laten we samen de Koran ontdekken!</p>
               <div className="absolute -right-8 -bottom-8 opacity-20 rotate-12"><BookOpen size={160} /></div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <button onClick={() => setActiveTab('quran')} className={`p-8 ${theme.card} rounded-[3rem] border-2 text-left active:scale-95 transition-all group border-emerald-100`}>
                <BookOpen className="text-emerald-500 mb-6 group-hover:scale-110 transition-transform" size={40} />
                <p className="font-black text-2xl">Koran</p>
                <p className="text-sm font-bold opacity-60">Luister mee!</p>
              </button>
              <button onClick={() => setActiveTab('chat')} className={`p-8 ${theme.card} rounded-[3rem] border-2 text-left active:scale-95 transition-all group border-blue-100`}>
                <MessageCircle className="text-blue-500 mb-6 group-hover:scale-110 transition-transform" size={40} />
                <p className="font-black text-2xl">Chat</p>
                <p className="text-sm font-bold opacity-60">Stel een vraag!</p>
              </button>
            </div>
          </div>
        )}

        {/* QURAN TAB */}
        {activeTab === 'quran' && (
          <div className="h-full overflow-y-auto px-6 no-scrollbar animate-in">
            {selectedSurah ? (
               <div className="flex flex-col items-center text-center py-10 relative min-h-full justify-center space-y-12 pb-32">
                  <button onClick={() => {setSelectedSurah(null); setIsPlaying(false); audioRef.current?.pause();}} className="absolute top-4 left-0 text-emerald-500 font-black flex items-center gap-1 uppercase text-[10px] tracking-widest"><ChevronLeft size={16}/> Terug</button>
                  <div className="relative">
                    <div className="w-56 h-56 bg-emerald-500/5 rounded-[4.5rem] border border-emerald-500/10 flex items-center justify-center relative z-10 shadow-2xl backdrop-blur-md">
                        {isLoadingAudio ? <Loader2 size={64} className="animate-spin text-emerald-500" /> : <BookOpen size={64} className="text-emerald-500" />}
                    </div>
                    <div className={`absolute inset-0 bg-emerald-500/20 blur-[80px] rounded-full transition-opacity duration-1000 ${isPlaying ? 'opacity-100' : 'opacity-0'}`}></div>
                  </div>
                  <div className="space-y-4">
                    <h3 className="text-4xl font-black tracking-tighter">{selectedSurah.englishName}</h3>
                    <p className="text-emerald-500 font-serif text-8xl mt-4 leading-normal">{selectedSurah.name}</p>
                  </div>
                  <button onClick={() => isPlaying ? (audioRef.current?.pause(), setIsPlaying(false)) : (audioRef.current?.play(), setIsPlaying(true))} className={`w-28 h-28 rounded-full flex items-center justify-center shadow-2xl active:scale-90 transition-all ${isDarkMode ? 'bg-white text-black' : 'bg-black text-white'}`}>
                    {isPlaying ? <Pause size={44} fill="currentColor" /> : <Play size={44} fill="currentColor" className="ml-2" />}
                  </button>
               </div>
            ) : (
              <div className="space-y-6 pt-8 pb-40">
                <h2 className="text-4xl font-black italic tracking-tighter">Koran</h2>
                <div className="relative sticky top-0 z-20 bg-inherit py-2">
                  <Search className={`absolute left-5 top-1/2 -translate-y-1/2 ${theme.subText}`} size={20} />
                  <input className={`w-full ${theme.input} border-none py-6 pl-14 pr-6 rounded-3xl outline-none font-black text-sm shadow-sm`} placeholder="ZOEKEN..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
                </div>
                <div className="space-y-4">
                  {surahs.filter(s => s.englishName.toLowerCase().includes(searchQuery.toLowerCase())).map(s => (
                    <button key={s.number} onClick={() => playSurah(s)} className={`w-full p-8 ${theme.card} rounded-[2.5rem] flex items-center justify-between border active:scale-[0.98] transition-all group`}>
                      <div className="flex items-center gap-6 text-left">
                        <span className="text-xs font-black opacity-20 group-hover:text-emerald-500 transition-colors">{String(s.number).padStart(3, '0')}</span>
                        <div>
                            <p className="font-black text-xl">{s.englishName}</p>
                            <p className="text-[10px] font-bold opacity-30 uppercase mt-1">{s.revelationType}</p>
                        </div>
                      </div>
                      <p className="text-emerald-500 font-serif text-3xl">{s.name}</p>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* CHAT TAB */}
        {activeTab === 'chat' && (
          <div className="absolute inset-0 flex flex-col pt-6 animate-in">
             <div className="flex-1 overflow-y-auto space-y-6 px-6 no-scrollbar pb-48 pt-12">
                {error && (
                  <div className="mx-auto bg-red-500/10 border border-red-500/20 p-4 rounded-2xl flex items-center gap-3 text-red-500 text-xs font-bold">
                    <AlertCircle size={14} /> {error}
                  </div>
                )}
                
                {messages.map((m, i) => (
                  <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[85%] px-7 py-5 rounded-[2.5rem] text-[15px] font-bold leading-relaxed ${m.role === 'user' ? 'bg-emerald-600 text-white rounded-tr-none shadow-lg' : `${theme.card} rounded-tl-none shadow-md`}`}>
                      {m.text}
                    </div>
                  </div>
                ))}
                {isTyping && (
                  <div className="flex gap-2 items-center ml-4 mt-2">
                    <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-bounce"></div>
                    <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-bounce [animation-delay:0.2s]"></div>
                    <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-bounce [animation-delay:0.4s]"></div>
                  </div>
                )}
                <div ref={messagesEndRef} />
             </div>
             
             <div className={`absolute bottom-28 left-6 right-6 flex gap-3 p-2 rounded-[2.5rem] backdrop-blur-3xl shadow-2xl border ${theme.glass}`}>
                <input 
                  className={`flex-1 bg-transparent border-none p-5 rounded-3xl outline-none font-black text-sm`} 
                  placeholder={isTyping ? "EVEN GEDULD..." : "STEL JE VRAAG..."} 
                  value={inputText} 
                  disabled={isTyping}
                  onChange={(e) => setInputText(e.target.value)} 
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()} 
                />
                <button 
                  onClick={handleSendMessage} 
                  disabled={isTyping || !inputText.trim()}
                  className={`w-14 h-14 rounded-3xl flex items-center justify-center active:scale-90 transition-all shadow-xl ${isTyping ? 'bg-gray-700 cursor-not-allowed opacity-50' : 'bg-emerald-600 text-white shadow-emerald-600/20'}`}
                >
                  {isTyping ? <Loader2 className="animate-spin" size={20} /> : <Send size={20} />}
                </button>
             </div>
          </div>
        )}

      </div>

      {/* NAVIGATION BAR */}
      <div className="fixed bottom-8 left-8 right-8 flex justify-center z-[200]">
        <div className={`h-20 w-full max-w-sm border rounded-[3rem] flex justify-around items-center px-4 shadow-2xl transition-all ${theme.glass}`}>
           {[
             { id: 'home', icon: <Home size={22} /> },
             { id: 'quran', icon: <BookOpen size={22} /> },
             { id: 'chat', icon: <MessageCircle size={22} /> }
           ].map(tab => (
             <button key={tab.id} onClick={() => {setActiveTab(tab.id); setSelectedSurah(null); setError(null);}} className={`relative p-5 transition-all duration-500 ${activeTab === tab.id ? 'text-emerald-500 scale-125' : 'opacity-20 hover:opacity-40'}`}>
                {tab.icon}
                {activeTab === tab.id && <div className="absolute bottom-2 left-1/2 -translate-x-1/2 w-1.5 h-1.5 bg-emerald-500 rounded-full"></div>}
             </button>
           ))}
        </div>
      </div>
        </div>
      )}
        </div>
      )}
    </AnimatePresence>
  );
}
